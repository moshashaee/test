# yourapp/tests/test_models.py
from django.test import TestCase
from menu.models import Category, Product, ProductImage

class ModelsTest(TestCase):
    def setUp(self):
        self.category = Category.objects.create(name='Test Category', is_sub=False)
        self.sub_category = Category.objects.create(name='Test Sub Category', is_sub=True, parent_category=self.category)
        self.product = Product.objects.create(name='Test Product', price=10, is_delete=False, status=1)
        self.product.category.add(self.category)
        self.product_image = ProductImage.objects.create(product=self.product, image='path/to/image.jpg')

    def test_category_model(self):
        category = Category.objects.get(id=self.category.id)
        self.assertEqual(category.name, 'Test Category')
        self.assertFalse(category.is_sub)  # Check the default value for is_sub

    def test_product_model(self):
        product = Product.objects.get(id=self.product.id)
        self.assertEqual(product.name, 'Test Product')
        self.assertEqual(product.price, 10)
        self.assertFalse(product.is_delete)  # Check the default value for is_delete
        self.assertEqual(product.status, 1)

        categories = product.category.all()
        self.assertIn(self.category, categories)
        self.assertNotIn(self.sub_category, categories)

    def test_product_image_model(self):
        product_image = ProductImage.objects.get(id=self.product_image.id)
        self.assertEqual(product_image.product, self.product)
        self.assertEqual(product_image.image, 'path/to/image.jpg')

    # Add more model test cases here

