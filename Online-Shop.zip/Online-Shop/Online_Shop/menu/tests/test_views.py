from django.test import TestCase, Client
from django.urls import reverse
from menu.models import Category, Product


class ViewsTest(TestCase):
    def setUp(self):
        self.client = Client()

    def test_category_page_view(self):
        url = reverse('category_page')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_category_list_view(self):
        url = reverse('category_list')
        response = self.client.post(url)
        self.assertEqual(response.status_code, 200)

    def test_sub_category_page_view(self):
        category = Category.objects.create(name='Test Category')
        url = reverse('sub_category_page', args=[category.name])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_sub_category_list_view(self):
        category = Category.objects.create(name='Test Category')
        url = reverse('sub_category_list', args=[category.name])
        response = self.client.post(url)
        self.assertEqual(response.status_code, 200)

    def test_product_page_view(self):
        category = Category.objects.create(name='Test Category')
        url = reverse('product_page', args=[category.name])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_product_list_view(self):
        category = Category.objects.create(name='Test Category')
        Product.objects.create(name='Product 1', category=category)
        url = reverse('product_list', args=[category.name])
        response = self.client.post(url)
        self.assertEqual(response.status_code, 200)

    def test_product_details_view(self):
        product = Product.objects.create(name='Product 1')
        url = reverse('product_details', args=[product.name])
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    # Add more test cases for other views

