from django.db import models

# Create your models here.


class Category(models.Model):
    name = models.CharField(max_length=100)
    image = models.ImageField(upload_to='menu/images/')
    parent_category = models.ForeignKey('self', on_delete=models.SET_NULL, null=True, blank=True)
    content = models.CharField(max_length=500, null=True)
    is_sub = models.BooleanField(default=False)


    def __str__(self):
        return self.name

class Product(models.Model):
    name = models.CharField(max_length=100)
    category = models.ManyToManyField(Category, related_name='products')
    
    content = models.CharField(max_length=500, null=True)
    price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    is_delete = models.BooleanField()
    STATUS_CHOICES = [
        (1, "available"),
        (2, "not_available"),
        (3, "comming_soon"),
        (4, "run_out_of_quantity")
        
    ]
    status = models.IntegerField(choices=STATUS_CHOICES, default=1, null=False)

    def __str__(self):
        return self.name
    

class ProductImage(models.Model):
    image = models.ImageField(upload_to='menu/images/', null=True)
    product = models.ForeignKey(Product , on_delete=models.CASCADE , related_name='images')

    def __str__(self):
        return f'image of {self.product.name}'
