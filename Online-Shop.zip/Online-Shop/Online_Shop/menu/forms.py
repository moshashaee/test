from django import forms



class AddToCartForm(forms.Form):
    quantity = forms.IntegerField(min_value=1 ,max_value=9 , widget=forms.NumberInput(attrs={'class': 'addtocart_form1', 'placeholder': 'Enter The Quantity'}))



class CategorySearchForm(forms.Form):
    search = forms.CharField(widget=forms.TextInput(attrs={'class': 'search_form1', 'placeholder': 'Which category You Looking For'}))


class ProductSearchForm(forms.Form):
    search = forms.CharField(widget=forms.TextInput(attrs={'class': 'search_form1', 'placeholder': 'Which product You Looking For'}))