from django.urls import path
from .views import ProductPageView , ProductListView , CategoryPageView , CategoryListView , ProductDetailsView , ProductDetailsListView , SubCategoryPageView , SubCategoryListView , CategorySearchResultsPage , CategorySearchResultsList , ProductSearchResultsPage , ProductSearchResultsList

urlpatterns = [
    path('category_page/', CategoryPageView.as_view(), name='category_page'),
    path('category_list/', CategoryListView.as_view(), name='category_list'),

    path('category_page/<str:category_name>/', SubCategoryPageView.as_view(), name='sub_category_page'),
    path('category_list/<str:category_name>/', SubCategoryListView.as_view(), name='sub_category_list'),

    path('category_results_page/', CategorySearchResultsPage.as_view(), name='category_results_page'),
    path('category_results_list/<str:search_request>/', CategorySearchResultsList.as_view(), name='category_results_list'),

    path('product_results_page/', ProductSearchResultsPage.as_view(), name='product_results_page'),
    path('product_results_list/<str:search_request>/', ProductSearchResultsList.as_view(), name='product_results_list'),

    path('product_page/<str:category_name>/', ProductPageView.as_view(), name='product_page'),
    path('product_list/<str:category_name>/', ProductListView.as_view(), name='product_list'),

    path('product_details/<str:product_name>/', ProductDetailsView.as_view(), name='product_details'),
    path('product_details_list/<str:product_name>/', ProductDetailsListView.as_view(), name='product_details_list'),

]