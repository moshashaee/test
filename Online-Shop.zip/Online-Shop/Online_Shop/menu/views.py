from django.shortcuts import render
from rest_framework.views import APIView
from django.views import View
from .models import Category , Product , ProductImage
from rest_framework.response import Response
from rest_framework import status
from .serializers import CategorySerializer , ProductSerializer , ProductImageSerializer
from rest_framework.pagination import PageNumberPagination
import math
from django.http import HttpResponse
from django.template import loader
from .forms import AddToCartForm , CategorySearchForm , ProductSearchForm
from django.views.decorators.cache import cache_page
from django.utils.decorators import method_decorator

# Create your views here.


class CategoryPageView(View):
    def get(self , request):
        form1 = CategorySearchForm()
        form2 = ProductSearchForm()
        category_count = Category.objects.filter(parent_category=None).count()
        button_count = math.ceil(category_count/2)
        print(button_count)
        return render(request, 'category_page.html' , {'category_count' : button_count , 'form1' : form1 , 'form2' : form2})
    


# Custom pagination class if you want to override the default settings.
class CustomPageNumberPagination1(PageNumberPagination):
    page_size = 2
    page_size_query_param = 'page_size'
    max_page_size = 100



class CategoryListView(APIView):
    def post(self, request):
        paginator = CustomPageNumberPagination1()
        categories = Category.objects.filter(parent_category=None)
        paginated_categories = paginator.paginate_queryset(categories, request)
        serializer = CategorySerializer(paginated_categories, many=True)

        # Manually construct the paginated response
        response = {
            'count': paginator.page.paginator.count,
            'next': paginator.get_next_link(),
            'previous': paginator.get_previous_link(),
            'results': serializer.data
        }
        return Response(response, status=status.HTTP_200_OK)
    



class SubCategoryPageView(View):
    def get(self,request , category_name):
        form1 = CategorySearchForm()
        form2 = ProductSearchForm()
        category = Category.objects.get(name=category_name)
        category_count = Category.objects.filter(parent_category=category).count()
        print(category_count)
        button_count = math.ceil(category_count/2)
        print(button_count)
        return render(request, 'sub_category_page.html' , {'category_count' : button_count , 'category_name':category_name , 'form1' : form1 , 'form2' : form2})

class SubCategoryListView(APIView):
    def post(self, request , category_name):
        paginator = CustomPageNumberPagination1()
        category = Category.objects.get(name=category_name)
        print(category)
        categories = Category.objects.filter(parent_category=category)
        print(categories)
        paginated_categories = paginator.paginate_queryset(categories, request)
        serializer = CategorySerializer(paginated_categories, many=True)

        # Manually construct the paginated response
        response = {
            'count': paginator.page.paginator.count,
            'next': paginator.get_next_link(),
            'previous': paginator.get_previous_link(),
            'results': serializer.data
        }
        return Response(response, status=status.HTTP_200_OK)




class ProductPageView(View):
    def get(self , request , category_name):
        print('why?????????')
        form1 = CategorySearchForm()
        form2 = ProductSearchForm()
        category = Category.objects.get(name=category_name)
        category_products_count = category.products.count()
        print(category_products_count)
        button_count = math.ceil(category_products_count/4)
        print(button_count)
        return render(request, 'product_page.html' , {'product_count' : button_count , 'category_name' : category_name , 'form1' : form1 , 'form2' : form2})
    


# Custom pagination class if you want to override the default settings.
class CustomPageNumberPagination2(PageNumberPagination):
    page_size = 4
    page_size_query_param = 'page_size'
    max_page_size = 100


class ProductListView(APIView):
    def post(self, request, category_name):
        paginator = CustomPageNumberPagination2()
        category = Category.objects.get(name=category_name)
        category_products = category.products.prefetch_related('images').all()
        
        print(category_products)
        paginated_categories = paginator.paginate_queryset(category_products, request)
        serializer = ProductSerializer(paginated_categories, many=True)

        # Manually construct the paginated response
        response = {
            'count': paginator.page.paginator.count,
            'next': paginator.get_next_link(),
            'previous': paginator.get_previous_link(),
            'results': serializer.data
        }
        return Response(response, status=status.HTTP_200_OK)
    


    


class ProductDetailsView(View):
    def get(self , request , product_name):
        form = AddToCartForm()
        return render(request, 'product_details.html', {'product_name' : product_name , 'form':form})
    

class ProductDetailsListView(APIView):
    @method_decorator(cache_page(60 * 15))
    def post(self , request , product_name):
        product = Product.objects.get(name=product_name)
        serializer = ProductSerializer(product)
        return Response(serializer.data, status=status.HTTP_200_OK )
    

class CategorySearchResultsPage(View):
    def post(self,request):

        form1 = CategorySearchForm(data=request.POST)
        
        form2 = ProductSearchForm()
        if form1.is_valid():
            search_request = form1.cleaned_data['search']
            form1 = CategorySearchForm()
            
            category_count = Category.objects.filter(name=search_request).count()

            button_count = math.ceil(category_count/2)
            
            return render(request, 'category_results_page.html' , {'category_count' : button_count , 'form1' : form1 , 'form2' : form2 , 'search_request' : search_request})
    



class CategorySearchResultsList(APIView):
    def post(self, request , search_request):
        paginator = CustomPageNumberPagination1()

        category = Category.objects.filter(name__icontains=search_request)

        paginated_categories = paginator.paginate_queryset(category, request)
        serializer = CategorySerializer(paginated_categories, many=True)

        # Manually construct the paginated response
        response = {
            'count': paginator.page.paginator.count,
            'next': paginator.get_next_link(),
            'previous': paginator.get_previous_link(),
            'results': serializer.data
        }
        
        return Response(response, status=status.HTTP_200_OK)
    




class ProductSearchResultsPage(View):
    def post(self,request):

        form2 = ProductSearchForm(data=request.POST)
        form1 = CategorySearchForm()
        
        if form2.is_valid():
            search_request = form2.cleaned_data['search']
            form2 = ProductSearchForm()
            
            product_count = Product.objects.filter(name=search_request).count()

            button_count = math.ceil(product_count/2)
            
            return render(request, 'product_results_page.html' , {'product_count' : button_count , 'form1' : form1 , 'form2' : form2 , 'search_request' : search_request})
    



class ProductSearchResultsList(APIView):
    def post(self, request , search_request):
        paginator = CustomPageNumberPagination1()

        product = Product.objects.filter(name__icontains=search_request)

        paginated_categories = paginator.paginate_queryset(product, request)
        serializer = ProductSerializer(paginated_categories, many=True)

        # Manually construct the paginated response
        response = {
            'count': paginator.page.paginator.count,
            'next': paginator.get_next_link(),
            'previous': paginator.get_previous_link(),
            'results': serializer.data
        }
        
        return Response(response, status=status.HTTP_200_OK)