from celery import shared_task

import smtplib
from Online_Shop import settings





@shared_task()
def send_confirmed_order_email():
    print('this is first task')
    with smtplib.SMTP_SSL(settings.EMAIL_HOST , settings.EMAIL_PORT_SSL) as server :
        server.login(settings.EMAIL_HOST_USER , settings.EMAIL_HOST_PASSWORD)
        server.sendmail(settings.EMAIL_HOST_USER , 'horcrax1998@gmail.com' , 'hello celery !!')


@shared_task
def send_paid_order_email():
    with smtplib.SMTP_SSL(settings.EMAIL_HOST , settings.EMAIL_PORT_SSL) as server :
        server.login(settings.EMAIL_HOST_USER , settings.EMAIL_HOST_PASSWORD)
        server.sendmail(settings.EMAIL_HOST_USER , 'horcrax1998@gmail.com' , 'byby celery !!')
    print('this is second task')
