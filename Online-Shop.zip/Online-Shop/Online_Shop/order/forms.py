from django import forms
from account.models import Address , Profile


class AddressSelectionForm(forms.Form):
    def __init__(self, user, *args, **kwargs):
        super(AddressSelectionForm, self).__init__(*args, **kwargs)
        profile = Profile.objects.get(user=user)
        self.fields['address'].queryset = Address.objects.filter(profile=profile)
        self.fields['address'].widget.attrs.update({'class': 'address_form'})

    address = forms.ModelChoiceField(queryset=Address.objects.all(), empty_label=None)