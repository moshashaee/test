from django.contrib import admin
from .models import Order , OrderProductItem , Transaction , CartItem
# Register your models here.


admin.site.register(Order)
admin.site.register(OrderProductItem)
admin.site.register(Transaction)
admin.site.register(CartItem)