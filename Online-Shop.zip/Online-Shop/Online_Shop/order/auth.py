from rest_framework_simplejwt.authentication import JWTAuthentication
import jwt
from rest_framework.exceptions import AuthenticationFailed
from rest_framework import status
from datetime import datetime
from django.conf import settings
from rest_framework.response import Response






class CustomJWTAuthentication(JWTAuthentication):
    def authenticate(self, request):
        try:
            # Extract the token from the Authorization header
            token = self.get_token_from_request(request)
            

            # Decode the token to get its payload
            payload = jwt.decode(token, settings.SECRET_KEY, algorithms=['HS256'])

            # Get the expiration time from the payload
            expiration_time = payload.get('exp', None)

            # Check if the token is expired
            if expiration_time is not None:
                
                current_time = datetime.utcnow().timestamp()
                if current_time > expiration_time:
                    print(0)
                    raise AuthenticationFailed("Token has expired.", code=status.HTTP_401_UNAUTHORIZED)

        except jwt.exceptions.ExpiredSignatureError:
            raise AuthenticationFailed("Token has expired.", code=status.HTTP_401_UNAUTHORIZED)

        except jwt.exceptions.DecodeError:
            raise AuthenticationFailed("Invalid token.", code=status.HTTP_401_UNAUTHORIZED)

        except jwt.exceptions.InvalidTokenError:
            raise AuthenticationFailed("Invalid token.", code=status.HTTP_401_UNAUTHORIZED)

        # If everything is valid, call the parent authenticate() method
        print('ok')
        return super().authenticate(request)

    def get_token_from_request(self, request):
        
        token = request.COOKIES.get('access_token')

        if token:
            
            return token
        return None
