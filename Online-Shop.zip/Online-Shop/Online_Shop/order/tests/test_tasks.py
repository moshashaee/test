from django.test import TestCase
from unittest.mock import patch
from order.tasks import send_confirmed_order_email, send_paid_order_email
from Online_Shop import settings

class CeleryTasksTestCase(TestCase):

    @patch('order.tasks.smtplib.SMTP_SSL')
    def test_send_confirmed_order_email(self, mock_smtp):
        task = send_confirmed_order_email

        
        smtp_instance = mock_smtp.return_value
        # smtp_instance.login.return_value = None

        
        task()

        # Assertions
        # smtp_instance.login.assert_called_once_with(settings.EMAIL_HOST_USER, settings.EMAIL_HOST_PASSWORD)
        # smtp_instance.sendmail.assert_called_once_with(settings.EMAIL_HOST_USER, 'horcrax1998@gmail.com', 'hello celery !!')

    @patch('order.tasks.smtplib.SMTP_SSL')
    def test_send_paid_order_email(self, mock_smtp):
        task = send_paid_order_email

        # Mock SMTP instance and login
        smtp_instance = mock_smtp.return_value
        smtp_instance.login.return_value = None

        # Call the task
        task()

        # Assertions
        smtp_instance.login.assert_called_once_with(settings.EMAIL_HOST_USER, settings.EMAIL_HOST_PASSWORD)
        smtp_instance.sendmail.assert_called_once_with(settings.EMAIL_HOST_USER, 'horcrax1998@gmail.com', 'byby celery !!')