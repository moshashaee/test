from django.test import TestCase, Client
from django.contrib.auth import get_user_model
from menu.models import Product
from order.models import CartItem, Order, OrderProductItem
from order.forms import AddressSelectionForm

User = get_user_model()

class YourViewTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(phone_number='0987654321', password='testpassword' , email='email')
        self.product = Product.objects.create(name='Test Product', price=10.0 , is_delete=False)

    def test_cart_view_authenticated(self):
        self.client.force_login(self.user)
        response = self.client.post('/cart_view/product_name/', {'quantity': 2})
        self.assertEqual(response.status_code, 404)
        
        

    def test_cart_view_unauthenticated(self):
        response = self.client.post('/cart_view/product_name/', {'quantity': 2})
        self.assertEqual(response.status_code, 404)
        
        

    

    def test_order_pay_view(self):
        self.client.force_login(self.user)
        address = AddressSelectionForm(user=self.user).save()
        cart_item = CartItem.objects.create(user=self.user, product=self.product, quantity=2)
        
        response = self.client.post('/order_pay_view/', {'address': address.id})
        self.assertEqual(response.status_code, 404)
        self.assertIn('/order_history_page/', response.url)
        

    def test_order_verify_view(self):
        self.client.force_login(self.user)
        response = self.client.get('/order_verify_view/', {'Authority': 'authority_here'})
        self.assertEqual(response.status_code, 404)
        
        