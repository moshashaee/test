from django.test import TestCase
from account.models import CustomUser
from menu.models import Product
from order.models import Order, OrderProductItem, Transaction, CartItem

class OrderModelTest(TestCase):
    def setUp(self):
        self.user = CustomUser.objects.create(phone_number='0987654321')
        self.order = Order.objects.create(user=self.user, address_line="123 Main St", city="City", state="State",
                                          country="Country", postal_code="12345")

    def test_order_str(self):
        self.assertEqual(str(self.order), f"Order #{self.order.pk}")

    def test_order_total_price(self):
        product = Product.objects.create(name="Test Product", price=10.0 , is_delete=False)
        OrderProductItem.objects.create(order=self.order, product=product, quantity=2)
        OrderProductItem.objects.create(order=self.order, product=product, quantity=3)
        
        self.assertEqual(self.order.final_price, 0)

    # Add more test cases for Order model

class OrderProductItemModelTest(TestCase):
    def setUp(self):
        self.user = CustomUser.objects.create(phone_number='0987654321')
        self.order = Order.objects.create(user=self.user, address_line="123 Main St", city="City", state="State",
                                          country="Country", postal_code="12345")
        self.product = Product.objects.create(name="Test Product", price=10.0 , is_delete=False)
        self.order_item = OrderProductItem.objects.create(order=self.order, product=self.product, quantity=2)

    def test_order_item_str(self):
        self.assertEqual(str(self.order_item), f"{self.product} x {self.order_item.quantity}")

    

class TransactionModelTest(TestCase):
    def setUp(self):
        self.user = CustomUser.objects.create(phone_number='0987654321')
        self.order = Order.objects.create(user=self.user, address_line="123 Main St", city="City", state="State",
                                          country="Country", postal_code="12345")
        self.transaction = Transaction.objects.create(order=self.order, final_price=50.0)

    def test_transaction_status_choices(self):
        self.assertEqual(self.transaction.get_status_display(), "Canceled")

    

class CartItemModelTest(TestCase):
    def setUp(self):
        self.user = CustomUser.objects.create(phone_number='0987654321')
        self.product = Product.objects.create(name="Test Product", price=10.0, is_delete=False)
        self.cart_item = CartItem.objects.create(user=self.user, product=self.product, quantity=3)

    def test_cart_item_quantity(self):
        self.assertEqual(self.cart_item.quantity, 3)