from django.urls import path
from .views import CartView , CartPageView , CartListView , OrderPageView , OrderListView , OrderHistoryPageView , OrderHistoryListView , OrderPayView , OrderVerifyView  , TransactionHistoryListView

urlpatterns = [
    path('cart/<str:product_name>/', CartView.as_view(), name='cart'),
    path('cart_page/', CartPageView.as_view(), name='cart_page'),
    path('cart_list/', CartListView.as_view(), name='cart_list'),
    path('cart_list/<str:product_name>/', CartListView.as_view(), name='cart_list'),

    path('order_page/', OrderPageView.as_view(), name='order_page'),
    path('order_page/<int:order_id>/', OrderPageView.as_view(), name='order_page'),
    path('order_list/', OrderListView.as_view(), name='order_list'),
    path('order_list/<int:order_id>/', OrderListView.as_view(), name='order_list'),

    path('history_page/', OrderHistoryPageView.as_view(), name='history_page'),
    path('history_list/', OrderHistoryListView.as_view(), name='history_list'),
    path('history_list/<int:order_id>/', OrderHistoryListView.as_view(), name='history_list'),


    
    path('transaction_history_list/', TransactionHistoryListView.as_view(), name='transaction_history_list'),
    path('transaction_history_list/<int:transaction_id>/', TransactionHistoryListView.as_view(), name='transaction_history_list'),

    path('pay_order/', OrderPayView.as_view(), name='pay_order'),
    path('verify/', OrderVerifyView.as_view(), name='verify'),




]