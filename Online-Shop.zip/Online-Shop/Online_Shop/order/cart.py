from django.http import HttpResponse
import json

CART_COOKIE_ID = 'cart'

class Cart():
    def __init__(self, request):
        self.cookie = request.COOKIES
        cart_json = self.cookie.get(CART_COOKIE_ID)
        if cart_json:
            try:
                # Parse the JSON string to a dictionary
                self.cart = json.loads(cart_json)
            except json.JSONDecodeError:
                self.cart = {}
        else:
            self.cart = {}
        # Always set the cart cookie in the response
        response = HttpResponse()  # Use HttpResponse instead of Response from DRF
        # Convert the cart dictionary to a JSON string when setting the cart cookie
        response.set_cookie(CART_COOKIE_ID, json.dumps(self.cart))


    def add(self, product , quantity):
        product_name = product.name
        if product_name not in self.cart :
            self.cart[product_name] = {'quantity' : 0 , 'price' : str(product.price)}
        self.cart[product_name]['quantity'] += quantity

