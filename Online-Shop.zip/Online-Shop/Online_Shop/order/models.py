from django.db import models
from account.models import CustomUser , Address
from menu.models import Product

# Create your models here.


class Order(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    order_date = models.DateTimeField(auto_now_add=True)
    address_line = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    country = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=20)
    STATUS_CHOICES = [
        (1, "new"),
        (2, "confirmed"),
        (3, "paid"),
        (4, "canceled")
        
    ]
    status = models.IntegerField(choices=STATUS_CHOICES, default=2, null=False)
    final_price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    is_delete = models.BooleanField(default=False)

    

    def __str__(self):
        return f"Order #{self.pk}"

class OrderProductItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    total_price = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def __str__(self):
        return f"{self.product} x {self.quantity}"
    

class Transaction(models.Model):
    order = models.ForeignKey(Order , on_delete=models.CASCADE)
    final_price = models.DecimalField(max_digits=10, decimal_places=2)
    transaction_date = models.DateTimeField(auto_now_add=True)
    
    STATUS_CHOICES = [
        (1, "Done"),
        (2, "Canceled"),
        (3, "not complete"),
       
        
    ]
    status = models.IntegerField(choices=STATUS_CHOICES, default=3, null=False)
    is_delete = models.BooleanField(default=False)
     


class CartItem(models.Model):
    user = models.ForeignKey(CustomUser , on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    cart_item_date = models.DateTimeField(auto_now_add=True)
    is_delete = models.BooleanField(default=False)