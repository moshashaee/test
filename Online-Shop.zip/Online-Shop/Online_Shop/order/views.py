from django.shortcuts import render , get_object_or_404 , redirect
from rest_framework.views import APIView
from django.views import View
from menu.forms import AddToCartForm
from rest_framework.response import Response
from rest_framework import status
from menu.models import Product , ProductImage
from .models import CartItem , Order , OrderProductItem , Transaction
from .serializers import CartItemSerializer , OrderSerializer , OrderProductItemSerializer , TransactionSerializer
from .forms import AddressSelectionForm


from .auth import CustomJWTAuthentication
from menu.serializers import ProductSerializer , ProductImageSerializer
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from .tasks import send_confirmed_order_email

import smtplib
from Online_Shop import settings



# Create your views here.



class CartView(APIView):
    
    def post(self, request, product_name):
        # Initialize the form with POST data
        form = AddToCartForm(request.POST)
        
        if request.user.is_authenticated:
            user = request.user
            
            if form.is_valid():
                redirect_url = f'/product_details/{product_name}'
                response = Response({'redirect_url': redirect_url}, status=status.HTTP_302_FOUND)
                product = Product.objects.get(name=product_name)
                cookie_value = request.COOKIES.get(product_name)
                
                if not cookie_value:
                    # If the product is not in the cart, set the cookie and update the cart item
                    response.set_cookie(str(product_name), form.cleaned_data['quantity'])

                    try:
                        cart = CartItem.objects.get(product=product, is_delete=False)
                        cart.quantity += form.cleaned_data['quantity']
                        cart.save()
                    except CartItem.DoesNotExist:
                        cart = CartItem.objects.create(user=user, product=product, quantity=form.cleaned_data['quantity'])

                else:
                    # If the product is already in the cart, update the quantity in the cookie and cart item
                    int_cookie_value = int(cookie_value)
                    int_cookie_value += form.cleaned_data['quantity']
                    response.set_cookie(str(product_name), int_cookie_value)

                    try:
                        cart = CartItem.objects.get(product=product)
                        cart.quantity = int_cookie_value
                        cart.save()
                    except CartItem.DoesNotExist:
                        cart = CartItem.objects.create(user=user, product=product, quantity=form.cleaned_data['quantity'] + int_cookie_value)

                return response
            
            return Response({'message': 'Error'}, status=status.HTTP_400_BAD_REQUEST)
        
        else:
            if form.is_valid():
                redirect_url = f'/product_details/{product_name}'
                response = Response({'redirect_url': redirect_url}, status=status.HTTP_302_FOUND)
                product = Product.objects.get(name=product_name)
                cookie_value = request.COOKIES.get(product_name)
                
                if not cookie_value:
                    # If the product is not in the cart, set the cookie
                    response.set_cookie(str(product_name), form.cleaned_data['quantity'])
                else:
                    # If the product is already in the cart, update the quantity in the cookie
                    int_cookie_value = int(cookie_value)
                    int_cookie_value += form.cleaned_data['quantity']
                    response.set_cookie(str(product_name), int_cookie_value)

                return response
            
            return Response({'message': 'Error'}, status=status.HTTP_400_BAD_REQUEST)
        


class CartPageView(View):
    def get(self , request):
        return render(request, 'cart_page.html')
    


class CartListView(APIView):
    
    def get(self, request, product_name=None):
        if product_name:
            # Handle product-specific logic if needed
            pass
        else:
            if request.user.is_authenticated:
                user = request.user
                
                # Iterate through all cookies stored in the request
                all_cookies = request.COOKIES
                for cookie_name, cookie_value in all_cookies.items():
                    if cookie_name in ['csrftoken', 'sessionid', 'access_token']:
                        # Skip system cookies
                        continue
                    else:
                        # Retrieve product corresponding to the cookie name
                        product = Product.objects.get(name=cookie_name)
                        
                        # Create or update cart item based on the user and product
                        cart = CartItem.objects.create(user=user, product=product, quantity=cookie_value)
                
                # Retrieve all cart items for the authenticated user
                all_cart_items = CartItem.objects.filter(user=user, is_delete=False)
                serializer = CartItemSerializer(all_cart_items, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            
            else:
                # Iterate through cookies for non-authenticated users
                all_cookies = request.COOKIES
                cart_item_list = []
                
                for cookie_name, cookie_value in all_cookies.items():
                    if cookie_name in ['csrftoken', 'sessionid', 'access_token']:
                        # Skip system cookies
                        continue
                    else:
                        # Retrieve product corresponding to the cookie name
                        product = Product.objects.get(name=cookie_name)
                        
                        try:
                            # Update existing cart item with new quantity
                            cart_item = CartItem.objects.get(product=product)
                            cart_item.quantity = cookie_value
                            cart_item.save()
                            cart_item_list.append(cart_item)
                        except CartItem.DoesNotExist:
                            # Create a new cart item if it doesn't exist
                            cart = CartItem.objects.create(user=None, product=product, quantity=cookie_value)
                            cart_item_list.append(cart)
                
                serializer = CartItemSerializer(cart_item_list, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request, product_name=None):
        if product_name:
            if request.user.is_authenticated:
                user = request.user
                product = Product.objects.get(name=product_name)
                
                # Retrieve and delete the cart item for the authenticated user and product
                cart_item = CartItem.objects.get(user=user, product=product)
                cart_item.delete()
                
                return Response(status=status.HTTP_200_OK)
            else:
                response = JsonResponse({"message": "Cookie deleted"})
                
                # Delete the cookie by setting an expired expiration date
                response.delete_cookie(f"{product_name}")
                
                return response
        else:
            # Handle other cases if needed
            pass
            
        
        

    



@method_decorator(login_required, name='dispatch')
class OrderPageView(View):
    def get(self , request , order_id=None):
        if order_id :
            user = request.user
            form = AddressSelectionForm(user)
            return render(request, 'order_page.html' , {'form' : form , 'order_id' : order_id})
        
        else:
            user = request.user
            form = AddressSelectionForm(user)
            return render(request, 'order_page.html' , {'form' : form})
    

class OrderListView(APIView):
    
    # Apply the login_required decorator to the entire class
    @method_decorator(login_required)
    def dispatch(self, *args, **kwargs):
        return super().dispatch(*args, **kwargs)
    
    def get(self, request, order_id=None):
        if order_id:
            user = request.user
            
            # Retrieve the specific order based on the order_id
            order = Order.objects.get(pk=order_id)
            
            # Retrieve product items associated with the order
            order_product_items = OrderProductItem.objects.filter(order=order)
            
            # Create a list of (quantity, product) tuples from order_product_items
            product_quantities = [(item.quantity, item.product) for item in order_product_items]
            
            # Filter CartItems based on the user, quantity, and product
            cart_items = CartItem.objects.select_related('user').filter(
                user=user,
                quantity__in=[quantity for quantity, _ in product_quantities],
                product__in=[product for _, product in product_quantities]
            )
            
            serializer = CartItemSerializer(cart_items, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        
        else:
            user = request.user
            
            # Retrieve cart items for the authenticated user that are not deleted
            cart_list = CartItem.objects.filter(user=user, is_delete=False)
            serializer = CartItemSerializer(cart_list, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
    




@method_decorator(login_required, name='dispatch')
class OrderHistoryPageView(View):
    def get(self , request):
        return render(request, 'history_page.html')
    


@method_decorator(login_required, name='dispatch')
class OrderHistoryListView(APIView):
    def get(self, request, order_id=None):
        if order_id:
            # Handle logic for a specific order_id
            user_cart_items = CartItem.objects.filter(user=request.user, is_delete=False)
            if len(user_cart_items) == 0:
                # Redirect to order page if the user has no cart items
                redirect_url = f'/order_page/{order_id}'
                return Response({'redirect_url': redirect_url}, status=status.HTTP_200_OK)
            else:
                # Return empty response if the user has cart items
                return Response({}, status=status.HTTP_204_NO_CONTENT)
        else:
            user = request.user
            
            # Retrieve confirmed, paid, and canceled orders for the user
            confirmed_orders = Order.objects.filter(user=user, status=2, is_delete=False)
            paid_orders = Order.objects.filter(user=user, status=3, is_delete=False)
            canceled_orders = Order.objects.filter(user=user, status=4, is_delete=False)
            
            # Serialize order data
            serializer1 = OrderSerializer(confirmed_orders, many=True)
            serializer2 = OrderSerializer(paid_orders, many=True)
            serializer3 = OrderSerializer(canceled_orders, many=True)
            
            # Retrieve order product items for each order status
            confirmed_items = OrderProductItem.objects.filter(order__in=confirmed_orders)
            paid_items = OrderProductItem.objects.filter(order__in=paid_orders)
            canceled_items = OrderProductItem.objects.filter(order__in=canceled_orders)
            
            # Serialize order product items
            serializer4 = OrderProductItemSerializer(confirmed_items, many=True)
            serializer5 = OrderProductItemSerializer(paid_items, many=True)
            serializer6 = OrderProductItemSerializer(canceled_items, many=True)
            
            # Prepare response data
            response_data = {
                'confirmed': serializer1.data,
                'paid': serializer2.data,
                'canceled': serializer3.data,
                'confirmed_items': serializer4.data,
                'paid_items': serializer5.data,
                'canceled_items': serializer6.data
            }
            return Response(response_data, status=status.HTTP_200_OK)

    def post(self, request, order_id):
        # Handle logic for marking an order as deleted
        order = Order.objects.get(pk=order_id)
        order.is_delete = True
        order.save()
        return Response(status=status.HTTP_200_OK)
    
    def delete(self, request):
        # Handle logic for marking all user orders as deleted
        user = request.user
        user_all_orders = Order.objects.filter(user=user)
        for order in user_all_orders:
            order.is_delete = True
            order.save()
        
        return Response(status=status.HTTP_204_NO_CONTENT)
    



@method_decorator(login_required, name='dispatch')
class TransactionHistoryListView(APIView):
    def post(self, request, transaction_id=None):
        if transaction_id:
            # Handle logic for marking a specific transaction as deleted
            transaction = Transaction.objects.get(pk=transaction_id)
            transaction.is_delete = True
            transaction.save()
            return Response(status=status.HTTP_200_OK)
        else:
            user = request.user
            
            # Retrieve done and canceled transactions for the user
            done_transactions = Transaction.objects.filter(order__user=user, status=1, is_delete=False)
            canceled_transactions = Transaction.objects.filter(order__user=user, status=2, is_delete=False)
            
            # Serialize transaction data
            serializer1 = TransactionSerializer(done_transactions, many=True)
            serializer2 = TransactionSerializer(canceled_transactions, many=True)
            
            # Prepare response data
            response_data = {
                'done': serializer1.data,
                'canceled': serializer2.data,
            }
            return Response(response_data, status=status.HTTP_200_OK)
    
    def delete(self, request):
        # Handle logic for marking all user transactions as deleted
        user = request.user
        transactions = Transaction.objects.filter(order__user=user, is_delete=False)
        for transaction in transactions:
            transaction.is_delete = True
            transaction.save()
        
        return Response(status=status.HTTP_204_NO_CONTENT)
    


        

        




'''
zarin pal

'''


from django.conf import settings
import requests
import json
from django.http import JsonResponse


#? sandbox merchant 
if settings.SANDBOX:
    sandbox = 'sandbox'
else:
    sandbox = 'www'


ZP_API_REQUEST = f"https://{sandbox}.zarinpal.com/pg/rest/WebGate/PaymentRequest.json"
ZP_API_VERIFY = f"https://{sandbox}.zarinpal.com/pg/rest/WebGate/PaymentVerification.json"
ZP_API_STARTPAY = f"https://{sandbox}.zarinpal.com/pg/StartPay/"

description = "توضیحات مربوط به تراکنش را در این قسمت وارد کنید"  # Requir

CallbackURL = 'http://127.0.0.1:8000/verify/'

@method_decorator(login_required, name='dispatch')
class OrderPayView(View):
    def post(self, request):
        user = request.user
        
        # Initialize the form with the user and POST data
        form = AddressSelectionForm(user, request.POST)
        
        if form.is_valid():
            address = form.cleaned_data['address']
            cart_items = CartItem.objects.filter(user=user, is_delete=False)
            
            global final_price
            final_price = []
            
            # Calculate the total price for all cart items
            for item in cart_items:
                final_price.append((item.product.price * item.quantity))
            
            # Create an order and a transaction
            order = Order.objects.create(
                user=user,
                final_price=sum(final_price),
                country=address.country,
                state=address.state,
                city=address.city,
                address_line=address.address_line,
                postal_code=address.postal_code
            )
            transaction = Transaction.objects.create(order=order, final_price=sum(final_price))
            
            # Store order and transaction IDs in the session
            request.session['current_order'] = order.id
            request.session['current_transaction'] = transaction.id
            
            # Create order product items and mark cart items as deleted
            for item in cart_items:
                order_product_item = OrderProductItem.objects.create(
                    order=order,
                    quantity=item.quantity,
                    product=item.product,
                    total_price=item.quantity * item.product.price
                )
                item.is_delete = True
                item.save()
            
            # Prepare data for payment API request
            data = {
                "MerchantID": settings.MERCHANT,
                "Amount": int(sum(final_price)),
                "Description": description,  # You should define this variable
                "Phone": user.phone_number,
                "CallbackURL": CallbackURL,  # You should define this variable
            }
            data = json.dumps(data)
            
            # Set headers for the API request
            headers = {'content-type': 'application/json', 'content-length': str(len(data))}
            
            try:
                # Make the API request to initiate payment
                response = requests.post(ZP_API_REQUEST, data=data, headers=headers, timeout=10)
                
                if response.status_code == 200:
                    response = response.json()
                    if response['Status'] == 100:
                        # Redirect user to payment gateway with authorization
                        redirect_url = f"{ZP_API_STARTPAY}{response['Authority']}/?status=true&authority={response['Authority']}"
                        return redirect(redirect_url)
                    else:
                        # Redirect user to payment failure page with error code
                        redirect_url = f"{ZP_API_STARTPAY}{response['Authority']}/?status=false&code={response['Status']}"
                        return redirect(redirect_url)
                
                return response
            
            except requests.exceptions.Timeout:
                # Redirect user to about page in case of a timeout
                redirect_url = "/about/"
                return redirect(redirect_url)
                 
            except requests.exceptions.ConnectionError:
                # Redirect user to contact us page in case of a connection error
                redirect_url = "/contact_us/"
                return redirect(redirect_url)

                
            

@method_decorator(login_required, name='dispatch')
class OrderVerifyView(View):
    def get(self, request):
        user = request.user
        
        # Retrieve the current order and transaction IDs from session
        order_id = request.session['current_order']
        transaction_id = request.session['current_transaction']
        
        # Retrieve the order and transaction objects based on the IDs
        order = get_object_or_404(Order, pk=order_id)
        transaction = get_object_or_404(Transaction, pk=transaction_id)
        
        # Prepare data for verification API request
        data = {
            "MerchantID": settings.MERCHANT,
            "Amount": int(order.final_price),
            "Authority": request.GET.get('Authority'),
        }
        data = json.dumps(data)
        
        # Set headers for the API request
        headers = {"accept": "application/json", 'content-type': 'application/json', 'content-length': str(len(data))}
        
        # Make the verification API request
        response = requests.post(ZP_API_VERIFY, data=data, headers=headers)
        
        if response.status_code == 200:
            response_json = response.json()
            
            if response_json['Status'] == 101 or response_json['Status'] == 100:
                # Payment succeeded
                order.status = 3
                order.save()

                transaction.status = 1
                transaction.save()

                redirect_url = f"history_page"
                
                # Send a payment confirmation email
                with smtplib.SMTP_SSL(settings.EMAIL_HOST, settings.EMAIL_PORT_SSL) as server:
                    server.login(settings.EMAIL_HOST_USER, settings.EMAIL_HOST_PASSWORD)
                    server.sendmail(settings.EMAIL_HOST_USER, user.email, f'you paid {order.final_price} !!')
                
                return redirect(redirect_url)
            else:
                # Payment failed or was canceled
                order.status = 4
                order.save()

                transaction.status = 2
                transaction.save()

                redirect_url = f"history_page"
                
                # Send a payment cancellation email
                with smtplib.SMTP_SSL(settings.EMAIL_HOST, settings.EMAIL_PORT_SSL) as server:
                    server.login(settings.EMAIL_HOST_USER, settings.EMAIL_HOST_PASSWORD)
                    server.sendmail(settings.EMAIL_HOST_USER, user.email, f'your payment process canceled !!')
                
                return redirect(redirect_url)
            
        return JsonResponse(response.json())
    




                    