from rest_framework import serializers
from .models import CartItem
from menu.serializers import ProductSerializer
from account.serializers import CustomUserSerializer
from .models import Order, OrderProductItem, Transaction

class CartItemSerializer(serializers.ModelSerializer):
    user = CustomUserSerializer()
    product = ProductSerializer()
    class Meta:
        model = CartItem
        fields = ['id', 'user', 'product', 'quantity']



class OrderSerializer(serializers.ModelSerializer):
    user = CustomUserSerializer()
    class Meta:
        model = Order
        fields = '__all__'


class OrderProductItemSerializer(serializers.ModelSerializer):
    
    product = ProductSerializer()
    class Meta:
        model = OrderProductItem
        fields = '__all__'



class TransactionSerializer(serializers.ModelSerializer):
    order = OrderSerializer()
    
    class Meta:
        model = Transaction
        fields = '__all__'