from kavenegar import *


def send_otp_code(phone_number , random_code):
    try :
        api = KavenegarAPI('573833494C4D4942473271754C316C6F545434754445484E65364E64663243424859654443527A414177553D') 
        params = { 'sender' : '', 'receptor': phone_number, 'message' : f'your verify code : {random_code}' } 
        response = api.sms_send( params) 
        print(response)

    except APIException as e: 
        print(e)
    except HTTPException as e: 
        print(e)







from celery import shared_task

import smtplib
from Online_Shop import settings

@shared_task
def send_ETIOM_email():
    with smtplib.SMTP_SSL(settings.EMAIL_HOST , settings.EMAIL_PORT_SSL) as server :
        server.login(settings.EMAIL_HOST_USER , settings.EMAIL_HOST_PASSWORD)
        server.sendmail(settings.EMAIL_HOST_USER , 'mostafamoshashaee1374@gmail.com' , 'every thing is ok mostafa !!')
    












# c8882f53-4327-4a15-a2de-858c67e4a971