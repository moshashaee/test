from django.shortcuts import render ,redirect
from rest_framework.views import APIView
from django.views import View
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth.hashers import make_password
import random
from .models import OtpCode, CustomUser , Profile , Address
from .forms import RegisterForm , LoginForm , VerifyCodeForm
from utils import send_otp_code
from django.contrib.auth import authenticate, logout , login 
from .serializers import RegisterSerializer , LoginSerializer , VerifyCodeSerializer ,CustomUserSerializer , AddressSerializer , ProfileSerializer , PetSerializer , OtpCodeSerializer , CustomTokenObtainPairSerializer
import requests
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.tokens import RefreshToken 
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
import smtplib
from Online_Shop import settings






class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer 


class RegisterPageView(View):
    def get(self, request):
        form = RegisterForm()
        return render(request, 'register.html' , {'form':form})
    

class RegisterView(APIView):
    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            phone_number = serializer.validated_data['phone_number']
            email = serializer.validated_data['email']
            password = serializer.validated_data['password2']
            hashed_password = make_password(password)

            random_code = random.randint(1000, 9999)
            print(random_code)
            send_otp_code(phone_number=phone_number, random_code=random_code)
            otp_code = OtpCode.objects.create(phone_number=phone_number, code=random_code)
            redirect_url = '/verify_page'
            response = Response({'redirect_url' : redirect_url} ,status=status.HTTP_302_FOUND)
            response.set_cookie('phone_number', phone_number)
            response.set_cookie('user_email', email)
            response.set_cookie('user_password', hashed_password)

            return response
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class VerifyPageView(View):
    def get(self , request):
        form = VerifyCodeForm()
        return render(request, 'verify.html' , {'form':form})

class VerifyView(APIView):

    def post(self, request):
        serializer = VerifyCodeSerializer(data=request.data)
        if serializer.is_valid():
            phone_number = request.COOKIES.get('phone_number')
            print(phone_number)
            email = request.COOKIES.get('user_email')
            hashed_password = request.COOKIES.get('user_password')

            back_code = OtpCode.objects.get(phone_number=phone_number)
            front_code = serializer.validated_data['code']

            if str(back_code) == front_code:
                user = CustomUser.objects.create(phone_number=phone_number, email=email, password=hashed_password)
                back_code.delete()
                profile = Profile.objects.create(user=user)
                
                redirect_url = '/login_page'
                response = Response({'redirect_url' : redirect_url}, status=status.HTTP_302_FOUND)
                for cookie in request.COOKIES:
                    response.delete_cookie(cookie)

                return response
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class LoginPageView(View):
    def get(self, request ):
        form = LoginForm()
        return render(request, 'login.html' , {'form':form})
    
class LoginView(APIView):

    def post(self, request):
        actions_value = request.POST.get('actions', None)
        token = None
        if actions_value == 'get':
            serializer = LoginSerializer()
            
            print('mosi')
            return Response(serializer.data, status=status.HTTP_200_OK)

        else : 
            serializer = LoginSerializer(data=request.data)
            if serializer.is_valid():
                
                password = serializer.validated_data.get('password')
                phone_number = serializer.validated_data.get('phone_number')



                user = authenticate(request, username=phone_number, password=password)
                refresh = RefreshToken.for_user(user)
                token = str(refresh.access_token)
                redirect_url = '/home'
                if user is not None:
                    login(request, user)
                    profile = Profile.objects.get(user=user)
                    if profile.first_name :
                        
                        with smtplib.SMTP_SSL(settings.EMAIL_HOST , settings.EMAIL_PORT_SSL) as server :
                            server.login(settings.EMAIL_HOST_USER , settings.EMAIL_HOST_PASSWORD)
                            server.sendmail(settings.EMAIL_HOST_USER , user.email , f'hello {profile.first_name} !!')
                    else :
                        
                        with smtplib.SMTP_SSL(settings.EMAIL_HOST , settings.EMAIL_PORT_SSL) as server :
                            server.login(settings.EMAIL_HOST_USER , settings.EMAIL_HOST_PASSWORD)
                            server.sendmail(settings.EMAIL_HOST_USER , user.email , f'hello new customer !! , please complete your profile !!')

                    return Response({
                        'message': 'Login successful',
                        'redirect_url': redirect_url,
                        'token': token
                    }, status=status.HTTP_200_OK)
                else:
                    return Response({'error': 'Invalid phone number or password'}, status=status.HTTP_401_UNAUTHORIZED)
            else:
                print('mosiiiiiiiiii')
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LogoutView(APIView):
    def post(self, request):
        redirect_url = '/home'
        logout(request)
        return Response({'message': 'Logged out successfully' , 'redirect_url':redirect_url}, status=status.HTTP_200_OK)
    
    




class ProfilePageView(View):
    def get(self , request):
        return render(request, 'profile_page.html')
    

@method_decorator(login_required, name='dispatch')
class ProfileListView(APIView):
    def get(self , request) :
        user = request.user
        profile = Profile.objects.get(user=user)
        serializer1 = ProfileSerializer(profile)

        address = Address.objects.filter(profile=profile)
        serializer2 = AddressSerializer(address, many=True)

        response_data = {
            'profile': serializer1.data,
            'addresses': serializer2.data
        }
        return Response(response_data, status=status.HTTP_200_OK)
    
    
    
    
    
    
    

#
# from .models import CustomUser , OtpCode
# from django.contrib.auth import authenticate, logout , login as auth_login
# 
# from django.contrib.auth.hashers import make_password
# import random
# from utils import send_otp_code

# # Create your views here.




# class RegisterView(View):
#     def get(self, request):
#         form = RegisterForm()
#         return render(request, 'register.html', {'form': form})

#     def post(self, request):
#         form = RegisterForm(request.POST)
#         if form.is_valid():
#             phone_number = form.cleaned_data['phone_number']
#             email = form.cleaned_data['email']
#             password = form.cleaned_data['password2']
#             hashed_password = make_password(password)

#             random_code = random.randint(1000,9999)
#             print(random_code)
#             send_otp_code(phone_number=phone_number , random_code=random_code)
#             otp_code = OtpCode.objects.create(phone_number=phone_number , code = random_code)

            

#             response = redirect('verify')
#             response.set_cookie('phone_number' , phone_number)
#             response.set_cookie('user_email', email)
#             response.set_cookie('user_password', hashed_password)

#             return response
            
            
            
#         return render(request, 'register.html', {'form': form})




# class VerifyView(View):
#     def get(self , request):
#         form = VerifyCodeForm()
#         return render(request, 'verify.html', {'form': form})

#     def post(self , request):
#         form = VerifyCodeForm(request.POST)
#         if form.is_valid():
            

#             phone_number = request.COOKIES.get('phone_number')
#             print(phone_number)
#             email = request.COOKIES.get('user_email')
#             hashed_password = request.COOKIES.get('user_password')

#             back_code = OtpCode.objects.get(phone_number=phone_number)
#             front_code = form.cleaned_data['code']


#             if str(back_code) == front_code :
                
#                 user = CustomUser.objects.create( phone_number=phone_number, email=email, password=hashed_password)
#                 back_code.delete()

#                 response = redirect('login')
#                 for cookie in request.COOKIES:
#                     response.delete_cookie(cookie)

#                 return response
            
#         return render(request, 'verify.html', {'form': form})
            


        




# class LoginView(View):
#     def get(self , request):
#         form = LoginForm()
#         return render(request, 'login.html', {'form': form})
#     def post(self, request):
#         actions = request.POST.get('actions')
#         if actions == 'get':
#             form = LoginForm()
#             return render(request, 'login.html', {'form': form})
        
#         if actions == 'post':
#             form = LoginForm(data=request.POST)
#             if form.is_valid():
#                 email = form.cleaned_data.get('email')
#                 password = form.cleaned_data.get('password')

#                 phone_number = form.cleaned_data.get('phone_number')
#                 user = authenticate(request, username=phone_number, password=password)

#                 if user is not None:
#                     auth_login(request, user)
#                     return redirect('home')
#                 else:
#                     form.add_error(None, 'Invalid phone number or password')

#             return render(request, 'login.html', {'form': form})



# class LogoutView(View):
#     def post(self, request):
#         logout(request)
#         return redirect('home')
