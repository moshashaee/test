from django.test import TestCase
from account.models import CustomUser, OtpCode, Address, Profile, Pet

class CustomUserModelTestCase(TestCase):
    def test_custom_user_creation(self):
        user = CustomUser.objects.create_user(phone_number="1234567890", email="test@example.com", password="testpassword123")
        self.assertIsInstance(user, CustomUser)
        self.assertTrue(user.is_active)
        self.assertFalse(user.is_admin)
        self.assertEqual(user.phone_number, "1234567890")
        self.assertEqual(user.email, "test@example.com")
        self.assertTrue(user.check_password("testpassword123"))

    def test_custom_user_str_representation(self):
        user = CustomUser.objects.create_user(phone_number="9876543210", email="test2@example.com", password="testpassword456")
        self.assertEqual(str(user), "9876543210")

class OtpCodeModelTestCase(TestCase):
    def test_otp_code_creation(self):
        otp_code = OtpCode.objects.create(phone_number="1234567890", code=1234)
        self.assertIsInstance(otp_code, OtpCode)
        self.assertEqual(otp_code.phone_number, "1234567890")
        self.assertEqual(otp_code.code, 1234)

    def test_otp_code_str_representation(self):
        otp_code = OtpCode.objects.create(phone_number="9876543210", code=5678)
        self.assertEqual(str(otp_code), "5678")

class AddressModelTestCase(TestCase):
    def test_address_creation(self):
        user = CustomUser.objects.create_user(phone_number="1234567890", email="test@example.com", password="testpassword123")
        address = Address.objects.create(user=user, address_line="123 Main St", city="Cityville", state="Stateville", country="Countryland")
        self.assertIsInstance(address, Address)
        self.assertEqual(address.user, user)
        self.assertEqual(address.address_line, "123 Main St")
        self.assertEqual(address.city, "Cityville")
        self.assertEqual(address.state, "Stateville")
        self.assertEqual(address.country, "Countryland")

    def test_address_str_representation(self):
        user = CustomUser.objects.create_user(phone_number="9876543210", email="test2@example.com", password="testpassword456")
        address = Address.objects.create(user=user, address_line="456 Park Ave", city="Townville", state="Stateville", country="Countryland")
        self.assertEqual(str(address), "456 Park Ave, Townville, Countryland")

class ProfileModelTestCase(TestCase):
    def test_profile_creation(self):
        user = CustomUser.objects.create_user(phone_number="1234567890", email="test@example.com", password="testpassword123")
        address = Address.objects.create(user=user, address_line="123 Main St", city="Cityville", state="Stateville", country="Countryland")
        profile = Profile.objects.create(first_name="John", last_name="Doe", birthdate="2000-01-01", user=user, address=address)
        self.assertIsInstance(profile, Profile)
        self.assertEqual(profile.first_name, "John")
        self.assertEqual(profile.last_name, "Doe")
        self.assertEqual(profile.birthdate, "2000-01-01")
        self.assertEqual(profile.user, user)
        self.assertEqual(profile.address, address)

    def test_profile_str_representation(self):
        user = CustomUser.objects.create_user(phone_number="9876543210", email="test2@example.com", password="testpassword456")
        address = Address.objects.create(user=user, address_line="456 Park Ave", city="Townville", state="Stateville", country="Countryland")
        profile = Profile.objects.create(first_name="Jane", last_name="Smith", birthdate="1990-01-01", user=user, address=address)
        self.assertEqual(str(profile), "John Doe")

class PetModelTestCase(TestCase):
    def test_pet_creation(self):
        user = CustomUser.objects.create_user(phone_number="1234567890", email="test@example.com", password="testpassword123")
        address = Address.objects.create(user=user, address_line="123 Main St", city="Cityville", state="Stateville", country="Countryland")
        profile = Profile.objects.create(first_name="John", last_name="Doe", birthdate="2000-01-01", user=user, address=address)
        pet = Pet.objects.create(name="Fluffy", age=5, kind="Dog", size="Medium", favorites="Toys, Treats", sensitivities="None", preferences="Warm bed", profile=profile)
        self.assertIsInstance(pet, Pet)
        self.assertEqual(pet.name, "Fluffy")
        self.assertEqual(pet.age, 5)
        self.assertEqual(pet.kind, "Dog")
        self.assertEqual(pet.size, "Medium")
        self.assertEqual(pet.favorites, "Toys, Treats")
        self.assertEqual(pet.sensitivities, "None")
        self.assertEqual(pet.preferences, "Warm bed")
        self.assertEqual(pet.profile, profile)

    def test_pet_str_representation(self):
        user = CustomUser.objects.create_user(phone_number="9876543210", email="test2@example.com", password="testpassword456")
        address = Address.objects.create(user=user, address_line="456 Park Ave", city="Townville", state="Stateville", country="Countryland")
        profile = Profile.objects.create(first_name="Jane", last_name="Smith", birthdate="1990-01-01", user=user, address=address)
        pet = Pet.objects.create(name="Max", age=3, kind="Cat", size="Small", favorites="Feather toys", sensitivities="None", preferences="Sunny spots", profile=profile)
        self.assertEqual(str(pet), "Max")
