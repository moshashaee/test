from django.test import TestCase, RequestFactory
from django.urls import reverse
from django.contrib.auth.hashers import check_password
from account.models import CustomUser, OtpCode
from django.contrib.auth.models import AnonymousUser



class AuthenticationTestCase(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.register_url = reverse('register')
        self.verify_url = reverse('verify')
        self.login_url = reverse('login')
        self.home_url = reverse('home')
        self.test_phone_number = '1234567890'
        self.test_email = 'test@example.com'
        self.test_password = 'testpassword123'

    def test_register_view(self):
        # Test successful registration
        data = {
            'phone_number': self.test_phone_number,
            'email': self.test_email,
            'password1': self.test_password,
            'password2': self.test_password
        }
        response = self.client.post(self.register_url, data)
        self.assertRedirects(response, self.verify_url)
        self.assertEqual(response.cookies['phone_number'].value, self.test_phone_number)
        self.assertEqual(response.cookies['user_email'].value, self.test_email)


    def test_register_view_invalid_data(self):
        # Test registration with invalid data
        data = {
            'phone_number': 'invalid_phone_number',
            'email': 'invalid_email',
            'password1': 'short',
            'password2': 'mismatched_password'
        }
        response = self.client.post(self.register_url, data)
        # Ensure the view returns to the registration page with form errors
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Enter a valid phone number')
        self.assertContains(response, 'Enter a valid email address')
        self.assertContains(response, 'Ensure this value has at least 8 characters')
        self.assertContains(response, 'The two password fields didn’t match.')


    def test_verify_view(self):
        # Test successful verification
        OtpCode.objects.create(phone_number=self.test_phone_number, code='1234')
        data = {'code': '1234'}
        response = self.client.post(self.verify_url, data)
        self.assertRedirects(response, self.login_url)
        self.assertIsNone(OtpCode.objects.filter(phone_number=self.test_phone_number).first())



    def test_verify_view_wrong_code(self):
        # Test verification with incorrect code
        OtpCode.objects.create(phone_number=self.test_phone_number, code='1234')
        data = {'code': '0000'}  # Provide a wrong verification code
        response = self.client.post(self.verify_url, data)
        # Ensure the view stays on the verification page with an error
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Invalid verification code')


    def test_login_view(self):
        # Test successful login
        user = CustomUser.objects.create_user(phone_number=self.test_phone_number, email=self.test_email, password=self.test_password)
        data = {'phone_number': self.test_phone_number, 'password': self.test_password}
        response = self.client.post(self.login_url, data)
        self.assertRedirects(response, self.home_url)
        self.assertTrue(check_password(self.test_password, user.password))

        # Test invalid login
        data = {'phone_number': self.test_phone_number, 'password': 'wrong_password'}
        response = self.client.post(self.login_url, data)
        self.assertFormError(response, 'form', None, 'Invalid phone number or password')




    def test_logout_view(self):
        # Test logout
        self.client.force_login(CustomUser.objects.create_user(phone_number=self.test_phone_number, email=self.test_email, password=self.test_password))
        response = self.client.get(reverse('logout'))
        self.assertRedirects(response, self.home_url)
        self.assertEqual(str(response.wsgi_request.user), str(AnonymousUser()))


    def test_logout_view_user_without_cookies(self):
        # Test logout for a user without cookies
        user = CustomUser.objects.create_user(phone_number=self.test_phone_number, email=self.test_email, password=self.test_password)
        self.client.force_login(user)
        response = self.client.get(reverse('logout'))
        # Ensure the view redirects to the home page after logout
        self.assertRedirects(response, self.home_url)
        # Check that the user is no longer authenticated
        self.assertEqual(str(response.wsgi_request.user), str(AnonymousUser()))















# coverage run --source='.' manage.py test 
