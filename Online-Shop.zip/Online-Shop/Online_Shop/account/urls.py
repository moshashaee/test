from django.urls import path
from .views import RegisterView, LoginView , LogoutView , VerifyView , LoginPageView , RegisterPageView , VerifyPageView , CustomTokenObtainPairView , ProfilePageView , ProfileListView
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)




urlpatterns = [
    path('api/login/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/login/refresh/', TokenRefreshView.as_view(), name='token_refresh'),

    path('register/', RegisterView.as_view(), name='register'),
    path('register_page/', RegisterPageView.as_view(), name='register_page'),
    path('verify_code/', VerifyView.as_view(), name='verify_code'),
    path('verify_page/', VerifyPageView.as_view(), name='verify_page'),
    path('login/', LoginView.as_view(), name='login'),
    path('login_page/', LoginPageView.as_view(), name='login_page'),
    path('logout/', LogoutView.as_view(), name='logout'),

    path('profile_page/', ProfilePageView.as_view(), name='profile_page'),
    path('profile_list/', ProfileListView.as_view(), name='profile_list'),
    
]