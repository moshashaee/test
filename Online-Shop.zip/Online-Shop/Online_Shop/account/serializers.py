from rest_framework import serializers
from .models import CustomUser, OtpCode, Address, Profile, Pet
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer



class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields[self.username_field] = self.fields['phone_number']

        
class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['phone_number', 'email', 'is_active', 'is_admin']


class OtpCodeSerializer(serializers.ModelSerializer):
    class Meta:
        model = OtpCode
        fields = ['phone_number', 'code', 'created_at']





class ProfileSerializer(serializers.ModelSerializer):
    user = CustomUserSerializer()
    class Meta:
        model = Profile
        fields = ['id', 'first_name', 'last_name', 'birthdate', 'image', 'user']


class AddressSerializer(serializers.ModelSerializer):
    profile = ProfileSerializer()
    class Meta:
        model = Address
        fields = ['id', 'address_line', 'city', 'state', 'country' ,'postal_code', 'profile']


class PetSerializer(serializers.ModelSerializer):
    class Meta:
        model = Pet
        fields = ['id', 'name', 'age', 'kind', 'size', 'favorites', 'sensitivities', 'preferences', 'image', 'profile']



class LoginSerializer(serializers.Serializer):
    phone_number = serializers.CharField()
    password = serializers.CharField()

class RegisterSerializer(serializers.Serializer):
    phone_number = serializers.CharField()
    email = serializers.EmailField()
    password1 = serializers.CharField()
    password2 = serializers.CharField()


class VerifyCodeSerializer(serializers.Serializer):
    code = serializers.CharField(max_length=4, write_only=True)