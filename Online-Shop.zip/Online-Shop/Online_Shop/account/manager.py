from django.contrib.auth.models import BaseUserManager , UserManager
# from django.core.exceptions import ValidationError


class CustomUserManager(BaseUserManager):
    def create_user(self, email, phone_number , password):
        """
        Creates and saves a User with the given details.
        """
        if not email:
            raise ValueError("Users must have an email address")

        if not phone_number:
            raise ValueError("Users must have an phone_number ")
        if not password:
            raise ValueError("Users must have an password ")


        user = self.model(
            email=self.normalize_email(email),
            
            phone_number=phone_number
            
        )

        # if len(password) < 8:
        #     raise ValidationError("Password must be at least 8 characters long.")

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, phone_number , password):
        """
        Creates and saves a superuser with the given details.
        """
        user = self.create_user(
            email,           
            phone_number,
            password
        )
        user.is_admin = True
        user.save(using=self._db)
        return user
    


