from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, AbstractUser
from django.core.validators import RegexValidator

from .manager import CustomUserManager





class CustomUser(AbstractBaseUser):
    
    is_active = models.BooleanField(
        "active status",
        default=True,
        help_text="Designates whether the user can log into this admin site.",
    )
    is_admin = models.BooleanField(
        "superuser status",
        default=False,
        help_text="Designates whether the user is superuser.",
    )
    
    phone_number_validator = RegexValidator(regex=r'^\+?1?\d{9,15}$',)
    phone_number = models.CharField(verbose_name="User Phone Number",
                                    null=False, max_length=11, unique=True,
                                    validators=[phone_number_validator])
    
    email = models.EmailField()




    
    USERNAME_FIELD = "phone_number"
    REQUIRED_FIELDS = ['email']
    
    objects = CustomUserManager()
    
    class Meta:
        verbose_name = "Custom User"
        verbose_name_plural = "Custom Users"
    
    def __str__(self):
        return self.phone_number
    
    def has_perm(self, perm, obj=None):
        "Does the user have a specific permission?"
        # Simplest possible answer: Yes, always
        return True
    
    def has_module_perms(self, app_label):
        "Does the user have permissions to view the app `app_label`?"
        # Simplest possible answer: Yes, always
        return True
    
    @property
    def is_staff(self):
        "Is the user a member of staff?"
        # Simplest possible answer: All admins are staff
        return self.is_admin
    

class OtpCode(models.Model):
    phone_number = models.CharField(max_length=11)
    code = models.PositiveSmallIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.code}'


class Profile(models.Model):
    first_name = models.CharField(max_length=50, null=True)
    last_name = models.CharField(max_length=50, null=True)
    birthdate = models.DateField(null=True)
    image = models.ImageField(upload_to='account/images/', null=True)
    user = models.OneToOneField(CustomUser , on_delete=models.CASCADE)

    
class Address(models.Model):
    profile = models.ForeignKey(Profile , on_delete=models.CASCADE, default=None)
    address_line = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    country = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=20)

    def __str__(self):
        return f"{self.address_line}, {self.city}, {self.country}"
    



    



class Pet(models.Model):
    name = models.CharField(max_length=50)
    age = models.SmallIntegerField()
    kind = models.CharField(max_length=100)
    size = models.CharField(max_length=50)
    favorites = models.CharField(max_length=1000)
    sensitivities = models.CharField(max_length=1000)
    preferences = models.CharField(max_length=1000)
    image = models.ImageField(upload_to='account/images/', null=True)
    profile = models.ForeignKey(Profile , on_delete=models.CASCADE)